"""
Simplified Adaptive System Test - Focus on Core Functionality

This test focuses on the adaptive polling system without the candle data rate limiting issues.
Tests the core functionality: polling frequency, snapshot saving, and database operations.

Always refer to official documentation: https://smartapi.angelone.in/docs
"""

import sys
import time
from datetime import datetime, timedelta
import pytz
from angel_login import angel_login
from option_chain_fetcher import OptionChainFetcher
from store_option_data_mysql import MySQLOptionDataStore

class SimplifiedAdaptiveTester:
    def __init__(self):
        self.ist_tz = pytz.timezone('Asia/Kolkata')
        self.test_duration = 300  # 5 minutes for faster testing
        self.total_polls = 0
        self.snapshots_saved = 0
        self.start_time = None
        self.end_time = None
        self.fetcher = None
        self.store = MySQLOptionDataStore()
    
    def floor_to_3min(self, timestamp):
        """Floor timestamp to the nearest 3-minute bucket"""
        minutes_since_midnight = timestamp.hour * 60 + timestamp.minute
        floored_minutes = (minutes_since_midnight // 3) * 3
        
        # Ensure floored_minutes is within valid range (0-59)
        if floored_minutes >= 60:
            # Handle edge case where floored_minutes could be 60
            floored_minutes = 57  # Last valid 3-minute interval
        
        floored_time = timestamp.replace(minute=floored_minutes, second=0, microsecond=0)
        return floored_time
    
    def check_database_entries(self, bucket_time):
        """Check how many database entries exist for a given bucket time"""
        try:
            connection = self.store.get_connection()
            if connection is None:
                return 0
            
            cursor = connection.cursor()
            
            # Check entries for this bucket time
            cursor.execute('''
                SELECT COUNT(*) FROM option_snapshots 
                WHERE bucket_ts = %s
            ''', (bucket_time,))
            
            result = cursor.fetchone()
            connection.close()
            
            if result and len(result) > 0:
                count_value, = result
                return int(count_value)
            return 0
            
        except Exception as e:
            print(f"⚠️  Error checking database entries: {str(e)}")
            return 0
    
    def run_test(self):
        """Run the simplified test for 5 minutes"""
        print("🧪 Starting Simplified Adaptive OI Tracking System Test")
        print("=" * 60)
        print(f"⏰ Test Duration: {self.test_duration // 60} minutes")
        print(f"🔄 Polling Frequency: 20 seconds")
        print(f"📊 Expected 3-minute buckets: {self.test_duration // 180}")
        print("=" * 60)
        
        try:
            # Login to Angel One
            print("🔐 Logging in to Angel One...")
            if not angel_login.login():
                print("❌ Failed to login. Cannot run test.")
                return False
            
            # Initialize fetcher
            smart_api = angel_login.get_smart_api()
            self.fetcher = OptionChainFetcher(smart_api)
            
            # Create new schema if needed
            print("🔧 Creating new schema...")
            self.store.create_new_schema()
            
            # Start test
            self.start_time = datetime.now(self.ist_tz)
            print(f"🚀 Test started at: {self.start_time.strftime('%H:%M:%S')}")
            
            # Run polling loop for test duration
            while datetime.now(self.ist_tz) - self.start_time < timedelta(seconds=self.test_duration):
                current_time = datetime.now(self.ist_tz)
                bucket_time = self.floor_to_3min(current_time)
                
                print(f"\n🔄 Poll #{self.total_polls + 1} at {current_time.strftime('%H:%M:%S')} (bucket: {bucket_time.strftime('%H:%M:%S')})")
                
                # Fetch data for all indices
                all_data = self.fetcher.fetch_all_indices_data(range_strikes=5)
                
                if all_data:
                    # Process each index data
                    for index_data in all_data:
                        index_name = index_data['index_name']
                        index_ltp = index_data['index_ltp']  # Use index LTP as close price
                        options = index_data['options']
                        
                        # Group options by strike for processing
                        strikes_data = {}
                        for option in options:
                            strike = option['strike']
                            option_type = option['type']
                            
                            if strike not in strikes_data:
                                strikes_data[strike] = {'CE': {}, 'PE': {}}
                            
                            strikes_data[strike][option_type] = {
                                'oi': option.get('oi', 0),
                                'ltp': option.get('ltp', 0)
                            }
                        
                        # Process each strike
                        for strike, strike_data in strikes_data.items():
                            trading_symbol = f"{index_name}{strike}"
                            
                            # Prepare current snapshot data
                            current_snapshot = {
                                'ce_oi': strike_data.get('CE', {}).get('oi', 0),
                                'pe_oi': strike_data.get('PE', {}).get('oi', 0),
                                'ce_ltp': strike_data.get('CE', {}).get('ltp', 0),
                                'pe_ltp': strike_data.get('PE', {}).get('ltp', 0)
                            }
                            
                            # Check if we should save snapshot
                            if self.fetcher.should_save_snapshot(trading_symbol, current_time):
                                # Use index LTP as close price (simplified approach)
                                close_price = index_ltp
                                
                                # Prepare snapshot for storage
                                snapshot_data = {
                                    'bucket_ts': bucket_time,
                                    'trading_symbol': trading_symbol,
                                    'option_type': 'XX',  # Placeholder, will be set per option
                                    'strike': strike,
                                    'ce_oi': current_snapshot['ce_oi'],
                                    'ce_price_close': close_price,
                                    'pe_oi': current_snapshot['pe_oi'],
                                    'pe_price_close': close_price
                                }
                                
                                # Store CE option
                                ce_snapshot = snapshot_data.copy()
                                ce_snapshot['option_type'] = 'CE'
                                if self.store.insert_single_snapshot(ce_snapshot):
                                    self.snapshots_saved += 1
                                
                                # Store PE option
                                pe_snapshot = snapshot_data.copy()
                                pe_snapshot['option_type'] = 'PE'
                                if self.store.insert_single_snapshot(pe_snapshot):
                                    self.snapshots_saved += 1
                                
                                print(f"✅ Saved snapshot for {trading_symbol} at {bucket_time.strftime('%H:%M:%S')}")
                                
                                # Check database entries for this bucket
                                entries_count = self.check_database_entries(bucket_time)
                                print(f"📊 Database entries for bucket {bucket_time.strftime('%H:%M:%S')}: {entries_count}")
                                
                                # Update last snapshot
                                self.fetcher.update_last_snapshot(trading_symbol, current_snapshot)
                
                self.total_polls += 1
                
                # Wait for next polling interval (20 seconds)
                time.sleep(20)
            
            # Test completed
            self.end_time = datetime.now(self.ist_tz)
            self.print_test_results()
            
            return True
            
        except Exception as e:
            print(f"❌ Test error: {str(e)}")
            return False
        
        finally:
            # Logout
            if angel_login.is_authenticated():
                angel_login.logout()
    
    def print_test_results(self):
        """Print comprehensive test results"""
        print("\n" + "=" * 60)
        print("🧪 TEST RESULTS")
        print("=" * 60)
        
        test_duration = self.end_time - self.start_time
        expected_buckets = int(test_duration.total_seconds() // 180)  # 3 minutes = 180 seconds
        
        print(f"⏰ Test Duration: {test_duration}")
        print(f"🔄 Total Polls: {self.total_polls}")
        print(f"📊 Snapshots Saved: {self.snapshots_saved}")
        print(f"🕐 Expected 3-min Buckets: {expected_buckets}")
        
        # Calculate statistics
        avg_polls_per_minute = self.total_polls / (test_duration.total_seconds() / 60)
        snapshots_per_bucket = self.snapshots_saved / max(expected_buckets, 1)
        
        print(f"\n📊 Statistics:")
        print(f"   Average polls per minute: {avg_polls_per_minute:.2f}")
        print(f"   Snapshots per 3-min bucket: {snapshots_per_bucket:.2f}")
        
        # Verify results
        print(f"\n✅ Verification:")
        
        if abs(avg_polls_per_minute - 3.0) <= 0.5:  # Allow some tolerance
            print("   ✅ Polling frequency is correct (~3 polls per minute)")
        else:
            print(f"   ❌ Polling frequency is incorrect: {avg_polls_per_minute:.2f} polls/min (expected ~3)")
        
        if snapshots_per_bucket <= 1.0:
            print("   ✅ Snapshots per bucket is within limits (≤1 per bucket)")
        else:
            print(f"   ❌ Too many snapshots per bucket: {snapshots_per_bucket:.2f}")
        
        print("\n🎉 Test completed!")

def main():
    """Main test function"""
    print("========================================")
    print("OI Tracker v3 Simplified System Test")
    print("========================================")
    print()
    print("This will run a 5-minute test of the adaptive polling system.")
    print("Expected results:")
    print("- ~3 polls per minute (20-second intervals)")
    print("- ≤1 snapshot per 3-minute bucket")
    print("- Uses index LTP as close price (simplified)")
    print()
    
    response = input("Continue with test? (y/N): ")
    if response.lower() != 'y':
        print("❌ Test cancelled.")
        return
    
    print("\nStarting 5-minute test...")
    tester = SimplifiedAdaptiveTester()
    success = tester.run_test()
    
    if not success:
        sys.exit(1)

if __name__ == "__main__":
    main() 