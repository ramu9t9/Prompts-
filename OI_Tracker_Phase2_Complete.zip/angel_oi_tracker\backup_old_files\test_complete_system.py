"""
Complete System Test for OI Tracker v3

This script tests all the new functionality:
1. Expiry management
2. Backfill system
3. OI analysis
4. Adaptive polling

Always refer to official documentation: https://smartapi.angelone.in/docs
"""

import time
from datetime import datetime, timedelta
import pytz
from angel_login import angel_login
from option_chain_fetcher import OptionChainFetcher
from backfill_system import BackfillSystem
from oi_analysis import OIAnalysis
from store_option_data_mysql import MySQLOptionDataStore
from utils.expiry_manager import get_current_expiry, get_all_expiries

def test_expiry_management():
    """Test expiry management functionality"""
    print("\n🧪 Testing Expiry Management...")
    print("=" * 50)
    
    try:
        # Test current expiry for NIFTY
        nifty_expiry = get_current_expiry('NIFTY')
        if nifty_expiry:
            print(f"✅ NIFTY current expiry: {nifty_expiry.strftime('%d%b%Y')}")
        else:
            print("❌ Failed to get NIFTY expiry")
        
        # Test current expiry for BANKNIFTY
        banknifty_expiry = get_current_expiry('BANKNIFTY')
        if banknifty_expiry:
            print(f"✅ BANKNIFTY current expiry: {banknifty_expiry.strftime('%d%b%Y')}")
        else:
            print("❌ Failed to get BANKNIFTY expiry")
        
        # Test all expiries for NIFTY
        all_nifty_expiries = get_all_expiries('NIFTY')
        if all_nifty_expiries:
            print(f"✅ NIFTY all expiries: {len(all_nifty_expiries)} found")
            for expiry in all_nifty_expiries[:3]:  # Show first 3
                print(f"   - {expiry.strftime('%d%b%Y')}")
        else:
            print("❌ Failed to get NIFTY expiries")
        
        return True
        
    except Exception as e:
        print(f"❌ Expiry management test failed: {str(e)}")
        return False

def test_backfill_system():
    """Test backfill system functionality"""
    print("\n🧪 Testing Backfill System...")
    print("=" * 50)
    
    try:
        backfill = BackfillSystem()
        
        # Test market hours detection
        is_open = backfill.is_market_open()
        print(f"📊 Market open: {is_open}")
        
        # Test last market day
        last_market_day = backfill.get_last_market_day()
        print(f"📅 Last market day: {last_market_day.strftime('%Y-%m-%d')}")
        
        # Test timestamp generation
        start_time = datetime.now(pytz.timezone('Asia/Kolkata')) - timedelta(hours=1)
        end_time = datetime.now(pytz.timezone('Asia/Kolkata'))
        timestamps = backfill.generate_backfill_timestamps(start_time, end_time)
        print(f"⏰ Generated {len(timestamps)} timestamps for 1-hour period")
        
        # Test smart backfill (without actually running it)
        print("🔄 Smart backfill logic tested (not executed)")
        
        return True
        
    except Exception as e:
        print(f"❌ Backfill system test failed: {str(e)}")
        return False

def test_oi_analysis():
    """Test OI analysis functionality"""
    print("\n🧪 Testing OI Analysis...")
    print("=" * 50)
    
    try:
        analyzer = OIAnalysis()
        
        # Test OI summary
        summary = analyzer.get_oi_summary('NIFTY', 1)  # Last 1 hour
        if summary:
            print(f"✅ OI summary generated for NIFTY")
            print(f"   - Total CE OI: {summary['total_ce_oi']:,}")
            print(f"   - Total PE OI: {summary['total_pe_oi']:,}")
            print(f"   - PCR: {summary['pcr']:.2f}")
        else:
            print("⚠️  No OI summary data available (normal if no data exists)")
        
        # Test strike analysis
        start_time = datetime.now(pytz.timezone('Asia/Kolkata')) - timedelta(hours=1)
        end_time = datetime.now(pytz.timezone('Asia/Kolkata'))
        strike_analysis = analyzer.get_strike_analysis('NIFTY', start_time, end_time)
        if strike_analysis:
            print(f"✅ Strike analysis generated for NIFTY")
            print(f"   - Strikes analyzed: {len(strike_analysis)}")
        else:
            print("⚠️  No strike analysis data available (normal if no data exists)")
        
        return True
        
    except Exception as e:
        print(f"❌ OI analysis test failed: {str(e)}")
        return False

def test_data_fetching():
    """Test data fetching functionality"""
    print("\n🧪 Testing Data Fetching...")
    print("=" * 50)
    
    try:
        # Login to Angel One
        if not angel_login.is_authenticated():
            print("🔐 Logging in to Angel One...")
            if not angel_login.login():
                print("❌ Failed to login. Cannot test data fetching.")
                return False
        
        smart_api = angel_login.get_smart_api()
        fetcher = OptionChainFetcher(smart_api)
        
        # Test expiry date fetching
        nifty_expiry = fetcher.get_expiry_date('NIFTY')
        if nifty_expiry:
            print(f"✅ NIFTY expiry date: {nifty_expiry}")
        else:
            print("❌ Failed to get NIFTY expiry date")
            return False
        
        # Test index LTP fetching
        nifty_ltp = fetcher.get_index_ltp('NIFTY')
        if nifty_ltp:
            print(f"✅ NIFTY LTP: {nifty_ltp}")
        else:
            print("❌ Failed to get NIFTY LTP")
            return False
        
        # Test option chain fetching (limited test)
        print("🔄 Testing option chain fetching...")
        all_data = fetcher.fetch_all_indices_data(range_strikes=3)  # Limited strikes for testing
        
        if all_data:
            print(f"✅ Successfully fetched data for {len(all_data)} indices")
            for index_data in all_data:
                index_name = index_data['index_name']
                options_count = len(index_data['options'])
                print(f"   - {index_name}: {options_count} options")
        else:
            print("❌ Failed to fetch option chain data")
            return False
        
        return True
        
    except Exception as e:
        print(f"❌ Data fetching test failed: {str(e)}")
        return False

def test_database_operations():
    """Test database operations"""
    print("\n🧪 Testing Database Operations...")
    print("=" * 50)
    
    try:
        store = MySQLOptionDataStore()
        
        # Test connection
        connection = store.get_connection()
        if connection:
            print("✅ Database connection successful")
            connection.close()
        else:
            print("❌ Database connection failed")
            return False
        
        # Test schema creation
        store.create_new_schema()
        print("✅ Schema creation/verification successful")
        
        # Test data insertion (mock data)
        test_snapshot = {
            'bucket_ts': datetime.now(pytz.timezone('Asia/Kolkata')),
            'trading_symbol': 'NIFTY_TEST',
            'option_type': 'CE',
            'strike': 19000,
            'ce_oi': 1000,
            'ce_price_close': 19000.0,
            'pe_oi': 1200,
            'pe_price_close': 19000.0
        }
        
        success = store.insert_single_snapshot(test_snapshot)
        if success:
            print("✅ Test data insertion successful")
        else:
            print("❌ Test data insertion failed")
            return False
        
        return True
        
    except Exception as e:
        print(f"❌ Database operations test failed: {str(e)}")
        return False

def run_complete_test():
    """Run all tests"""
    print("🚀 Starting Complete System Test for OI Tracker v3")
    print("=" * 60)
    
    test_results = {}
    
    # Run all tests
    test_results['expiry_management'] = test_expiry_management()
    test_results['backfill_system'] = test_backfill_system()
    test_results['oi_analysis'] = test_oi_analysis()
    test_results['data_fetching'] = test_data_fetching()
    test_results['database_operations'] = test_database_operations()
    
    # Print summary
    print("\n📊 Test Results Summary")
    print("=" * 60)
    
    passed = 0
    total = len(test_results)
    
    for test_name, result in test_results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{test_name.replace('_', ' ').title():<25} {status}")
        if result:
            passed += 1
    
    print("-" * 60)
    print(f"Overall Result: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! System is ready for production.")
    else:
        print("⚠️  Some tests failed. Please check the errors above.")
    
    return passed == total

def main():
    """Main function"""
    try:
        success = run_complete_test()
        if success:
            print("\n✅ System test completed successfully!")
        else:
            print("\n❌ System test completed with failures.")
        
    except KeyboardInterrupt:
        print("\n🛑 Test interrupted by user")
    except Exception as e:
        print(f"\n❌ Test failed with error: {str(e)}")

if __name__ == "__main__":
    main() 