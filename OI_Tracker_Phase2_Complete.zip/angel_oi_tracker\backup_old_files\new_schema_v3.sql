-- New Simplified Schema for OI Tracking v3
-- This schema focuses on essential data with candle close prices

CREATE TABLE IF NOT EXISTS option_snapshots (
    bucket_ts TIMESTAMP NOT NULL,
    trading_symbol VARCHAR(25) NOT NULL,
    option_type CHAR(2) NOT NULL,
    strike INT NOT NULL,
    ce_oi BIGINT DEFAULT 0,
    ce_price_close DECIMAL(10,2) DEFAULT 0,
    pe_oi BIGINT DEFAULT 0,
    pe_price_close DECIMAL(10,2) DEFAULT 0,
    PRIMARY KEY(bucket_ts, trading_symbol)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Performance indexes
CREATE INDEX IF NOT EXISTS idx_bucket_ts ON option_snapshots(bucket_ts);
CREATE INDEX IF NOT EXISTS idx_trading_symbol ON option_snapshots(trading_symbol);
CREATE INDEX IF NOT EXISTS idx_strike ON option_snapshots(strike);
CREATE INDEX IF NOT EXISTS idx_bucket_symbol ON option_snapshots(bucket_ts, trading_symbol); 