"""
Backfill System for OI Tracker v3

This module handles backfill scenarios:
1. Mid-market starts - backfill missed data from market open
2. After-market analysis - fetch complete day's data
3. Weekend analysis - fetch last market day's data
4. Expiry handling - manage expired contracts

Always refer to official documentation: https://smartapi.angelone.in/docs
"""

import time
from datetime import datetime, timedelta
import pytz
from angel_login import angel_login
from option_chain_fetcher import OptionChainFetcher
from store_option_data_mysql import MySQLOptionDataStore
from utils.expiry_manager import get_current_expiry, get_all_expiries

class BackfillSystem:
    def __init__(self):
        self.ist_tz = pytz.timezone('Asia/Kolkata')
        self.store = MySQLOptionDataStore()
        
    def is_market_open(self):
        """Check if market is currently open"""
        now = datetime.now(self.ist_tz)
        
        # Check if it's a weekday (Monday = 0, Sunday = 6)
        if now.weekday() >= 5:  # Saturday or Sunday
            return False
        
        # Check market hours (9:18 AM to 3:30 PM IST)
        market_start = now.replace(hour=9, minute=18, second=0, microsecond=0)
        market_end = now.replace(hour=15, minute=30, second=0, microsecond=0)
        
        return market_start <= now <= market_end
    
    def get_market_hours(self, date=None):
        """Get market start and end times for a given date"""
        if date is None:
            date = datetime.now(self.ist_tz)
        
        market_start = date.replace(hour=9, minute=18, second=0, microsecond=0)
        market_end = date.replace(hour=15, minute=30, second=0, microsecond=0)
        
        return market_start, market_end
    
    def get_last_market_day(self):
        """Get the last market day (excluding weekends)"""
        now = datetime.now(self.ist_tz)
        current_day = now
        
        # Go back until we find a weekday
        while current_day.weekday() >= 5:  # Saturday or Sunday
            current_day -= timedelta(days=1)
        
        return current_day
    
    def generate_backfill_timestamps(self, start_time, end_time):
        """Generate 3-minute interval timestamps between start and end time"""
        timestamps = []
        current_time = start_time
        
        while current_time <= end_time:
            timestamps.append(current_time)
            current_time += timedelta(minutes=3)
        
        return timestamps
    
    def check_existing_data(self, bucket_time, trading_symbol):
        """Check if data already exists for the given bucket and symbol"""
        try:
            connection = self.store.get_connection()
            if connection is None:
                return False
            
            cursor = connection.cursor()
            cursor.execute('''
                SELECT COUNT(*) FROM option_snapshots 
                WHERE bucket_ts = %s AND trading_symbol = %s
            ''', (bucket_time, trading_symbol))
            
            result = cursor.fetchone()
            connection.close()
            
            if result and len(result) > 0:
                count_value, = result
                return int(count_value) > 0
            return False
            
        except Exception as e:
            print(f"⚠️  Error checking existing data: {str(e)}")
            return False
    
    def backfill_mid_market(self):
        """Backfill data from market start to current time"""
        print("🔄 Starting mid-market backfill...")
        
        try:
            # Get market start time for today
            today = datetime.now(self.ist_tz)
            market_start, market_end = self.get_market_hours(today)
            current_time = datetime.now(self.ist_tz)
            
            # If market hasn't started yet, no backfill needed
            if current_time < market_start:
                print("✅ Market hasn't started yet. No backfill needed.")
                return True
            
            # Generate timestamps from market start to current time
            end_time = min(current_time, market_end)
            timestamps = self.generate_backfill_timestamps(market_start, end_time)
            
            print(f"📅 Backfilling {len(timestamps)} timestamps from {market_start.strftime('%H:%M')} to {end_time.strftime('%H:%M')}")
            
            return self._execute_backfill(timestamps, "mid-market")
            
        except Exception as e:
            print(f"❌ Error in mid-market backfill: {str(e)}")
            return False
    
    def backfill_complete_day(self, target_date=None):
        """Backfill complete day's data"""
        print("🔄 Starting complete day backfill...")
        
        try:
            if target_date is None:
                target_date = datetime.now(self.ist_tz)
            
            market_start, market_end = self.get_market_hours(target_date)
            timestamps = self.generate_backfill_timestamps(market_start, market_end)
            
            print(f"📅 Backfilling complete day: {target_date.strftime('%Y-%m-%d')}")
            print(f"📊 {len(timestamps)} timestamps from {market_start.strftime('%H:%M')} to {market_end.strftime('%H:%M')}")
            
            return self._execute_backfill(timestamps, "complete-day")
            
        except Exception as e:
            print(f"❌ Error in complete day backfill: {str(e)}")
            return False
    
    def backfill_last_market_day(self):
        """Backfill last market day's data (for weekend analysis)"""
        print("🔄 Starting last market day backfill...")
        
        try:
            last_market_day = self.get_last_market_day()
            return self.backfill_complete_day(last_market_day)
            
        except Exception as e:
            print(f"❌ Error in last market day backfill: {str(e)}")
            return False
    
    def _execute_backfill(self, timestamps, backfill_type):
        """Execute the actual backfill process"""
        try:
            # Login to Angel One
            if not angel_login.is_authenticated():
                print("🔐 Logging in to Angel One...")
                if not angel_login.login():
                    print("❌ Failed to login. Cannot perform backfill.")
                    return False
            
            smart_api = angel_login.get_smart_api()
            fetcher = OptionChainFetcher(smart_api)
            
            # Create schema if needed
            self.store.create_new_schema()
            
            success_count = 0
            total_processed = 0
            
            for i, timestamp in enumerate(timestamps, 1):
                print(f"🔄 Processing {i}/{len(timestamps)}: {timestamp.strftime('%H:%M:%S')}")
                
                try:
                    # Fetch data for all indices
                    all_data = fetcher.fetch_all_indices_data(range_strikes=5)
                    
                    if all_data:
                        # Process each index data
                        for index_data in all_data:
                            index_name = index_data['index_name']
                            index_ltp = index_data['index_ltp']
                            options = index_data['options']
                            
                            # Group options by strike
                            strikes_data = {}
                            for option in options:
                                strike = option['strike']
                                option_type = option['type']
                                
                                if strike not in strikes_data:
                                    strikes_data[strike] = {'CE': {}, 'PE': {}}
                                
                                strikes_data[strike][option_type] = {
                                    'oi': option.get('oi', 0),
                                    'ltp': option.get('ltp', 0)
                                }
                            
                            # Process each strike
                            for strike, strike_data in strikes_data.items():
                                trading_symbol = f"{index_name}{strike}"
                                
                                # Check if data already exists
                                if self.check_existing_data(timestamp, trading_symbol):
                                    continue
                                
                                # Prepare snapshot data
                                snapshot_data = {
                                    'bucket_ts': timestamp,
                                    'trading_symbol': trading_symbol,
                                    'option_type': 'XX',
                                    'strike': strike,
                                    'ce_oi': strike_data.get('CE', {}).get('oi', 0),
                                    'ce_price_close': index_ltp,
                                    'pe_oi': strike_data.get('PE', {}).get('oi', 0),
                                    'pe_price_close': index_ltp
                                }
                                
                                # Store CE option
                                ce_snapshot = snapshot_data.copy()
                                ce_snapshot['option_type'] = 'CE'
                                if self.store.insert_single_snapshot(ce_snapshot):
                                    success_count += 1
                                
                                # Store PE option
                                pe_snapshot = snapshot_data.copy()
                                pe_snapshot['option_type'] = 'PE'
                                if self.store.insert_single_snapshot(pe_snapshot):
                                    success_count += 1
                                
                                total_processed += 2
                    
                    # Small delay between requests
                    time.sleep(1)
                    
                except Exception as e:
                    print(f"❌ Error processing {timestamp}: {str(e)}")
                    continue
            
            print(f"🎉 {backfill_type} backfill completed!")
            print(f"✅ Successfully processed {success_count}/{total_processed} snapshots")
            
            return success_count > 0
            
        except Exception as e:
            print(f"❌ Error in backfill execution: {str(e)}")
            return False
    
    def calculate_oi_changes(self, trading_symbol, days_back=1):
        """Calculate OI changes for a trading symbol over the specified period"""
        try:
            connection = self.store.get_connection()
            if connection is None:
                return None
            
            cursor = connection.cursor()
            
            # Get data for the specified period
            end_date = datetime.now(self.ist_tz)
            start_date = end_date - timedelta(days=days_back)
            
            cursor.execute('''
                SELECT bucket_ts, ce_oi, pe_oi, ce_price_close, pe_price_close
                FROM option_snapshots 
                WHERE trading_symbol = %s AND bucket_ts BETWEEN %s AND %s
                ORDER BY bucket_ts
            ''', (trading_symbol, start_date, end_date))
            
            records = cursor.fetchall()
            connection.close()
            
            if not records:
                return None
            
            # Calculate changes
            changes = []
            for i in range(1, len(records)):
                prev_record = records[i-1]
                curr_record = records[i]
                
                ce_oi_change = curr_record[1] - prev_record[1]
                pe_oi_change = curr_record[2] - prev_record[2]
                ce_price_change = curr_record[3] - prev_record[3]
                pe_price_change = curr_record[4] - prev_record[4]
                
                changes.append({
                    'timestamp': curr_record[0],
                    'ce_oi_change': ce_oi_change,
                    'pe_oi_change': pe_oi_change,
                    'ce_price_change': ce_price_change,
                    'pe_price_change': pe_price_change
                })
            
            return changes
            
        except Exception as e:
            print(f"❌ Error calculating OI changes: {str(e)}")
            return None
    
    def run_smart_backfill(self):
        """Run intelligent backfill based on current situation"""
        print("🧠 Running smart backfill analysis...")
        
        current_time = datetime.now(self.ist_tz)
        is_weekend = current_time.weekday() >= 5
        market_open = self.is_market_open()
        
        print(f"📅 Current time: {current_time.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"📊 Weekend: {is_weekend}")
        print(f"📊 Market open: {market_open}")
        
        if is_weekend:
            print("🔄 Weekend detected - backfilling last market day...")
            return self.backfill_last_market_day()
        
        elif market_open:
            print("🔄 Market is open - backfilling from market start...")
            return self.backfill_mid_market()
        
        else:
            print("🔄 Market is closed - backfilling complete day...")
            return self.backfill_complete_day()

def main():
    """Main function for testing backfill system"""
    backfill = BackfillSystem()
    success = backfill.run_smart_backfill()
    
    if success:
        print("✅ Backfill completed successfully!")
    else:
        print("❌ Backfill failed!")

if __name__ == "__main__":
    main() 