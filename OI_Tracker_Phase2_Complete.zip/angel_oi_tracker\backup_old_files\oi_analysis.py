"""
OI Analysis Module for OI Tracker v3

This module provides OI change analysis and insights:
1. OI change calculations over different time periods
2. Strike-wise OI analysis
3. CE vs PE OI ratio analysis
4. Historical OI trends

Always refer to official documentation: https://smartapi.angelone.in/docs
"""

import pandas as pd
from datetime import datetime, timedelta
import pytz
from store_option_data_mysql import MySQLOptionDataStore

class OIAnalysis:
    def __init__(self):
        self.ist_tz = pytz.timezone('Asia/Kolkata')
        self.store = MySQLOptionDataStore()
    
    def get_oi_changes(self, trading_symbol, start_time=None, end_time=None):
        """Get OI changes for a trading symbol over a time period"""
        try:
            connection = self.store.get_connection()
            if connection is None:
                return None
            
            if start_time is None:
                start_time = datetime.now(self.ist_tz) - timedelta(days=1)
            if end_time is None:
                end_time = datetime.now(self.ist_tz)
            
            cursor = connection.cursor()
            cursor.execute('''
                SELECT bucket_ts, ce_oi, pe_oi, ce_price_close, pe_price_close
                FROM option_snapshots 
                WHERE trading_symbol = %s AND bucket_ts BETWEEN %s AND %s
                ORDER BY bucket_ts
            ''', (trading_symbol, start_time, end_time))
            
            records = cursor.fetchall()
            connection.close()
            
            if not records:
                return None
            
            # Calculate changes
            changes = []
            for i in range(1, len(records)):
                prev_record = records[i-1]
                curr_record = records[i]
                
                ce_oi_change = curr_record[1] - prev_record[1]
                pe_oi_change = curr_record[2] - prev_record[2]
                ce_price_change = curr_record[3] - prev_record[3]
                pe_price_change = curr_record[4] - prev_record[4]
                
                # Calculate percentage changes
                ce_oi_pct_change = (ce_oi_change / prev_record[1] * 100) if prev_record[1] > 0 else 0
                pe_oi_pct_change = (pe_oi_change / prev_record[2] * 100) if prev_record[2] > 0 else 0
                
                changes.append({
                    'timestamp': curr_record[0],
                    'ce_oi_change': ce_oi_change,
                    'pe_oi_change': pe_oi_change,
                    'ce_oi_pct_change': ce_oi_pct_change,
                    'pe_oi_pct_change': pe_oi_pct_change,
                    'ce_price_change': ce_price_change,
                    'pe_price_change': pe_price_change,
                    'ce_oi': curr_record[1],
                    'pe_oi': curr_record[2],
                    'ce_price': curr_record[3],
                    'pe_price': curr_record[4]
                })
            
            return changes
            
        except Exception as e:
            print(f"❌ Error getting OI changes: {str(e)}")
            return None
    
    def get_strike_analysis(self, index_name, start_time=None, end_time=None):
        """Get OI analysis for all strikes of an index"""
        try:
            connection = self.store.get_connection()
            if connection is None:
                return None
            
            if start_time is None:
                start_time = datetime.now(self.ist_tz) - timedelta(days=1)
            if end_time is None:
                end_time = datetime.now(self.ist_tz)
            
            cursor = connection.cursor()
            cursor.execute('''
                SELECT trading_symbol, option_type, strike,
                       MAX(ce_oi) as max_ce_oi, MIN(ce_oi) as min_ce_oi,
                       MAX(pe_oi) as max_pe_oi, MIN(pe_oi) as min_pe_oi,
                       AVG(ce_oi) as avg_ce_oi, AVG(pe_oi) as avg_pe_oi,
                       COUNT(*) as data_points
                FROM option_snapshots 
                WHERE trading_symbol LIKE %s AND bucket_ts BETWEEN %s AND %s
                GROUP BY trading_symbol, option_type, strike
                ORDER BY strike
            ''', (f"{index_name}%", start_time, end_time))
            
            records = cursor.fetchall()
            connection.close()
            
            if not records:
                return None
            
            # Process records
            analysis = {}
            for record in records:
                trading_symbol, option_type, strike = record[0], record[1], record[2]
                
                if strike not in analysis:
                    analysis[strike] = {
                        'strike': strike,
                        'ce': {
                            'max_oi': 0, 'min_oi': 0, 'avg_oi': 0,
                            'current_oi': 0, 'oi_change': 0
                        },
                        'pe': {
                            'max_oi': 0, 'min_oi': 0, 'avg_oi': 0,
                            'current_oi': 0, 'oi_change': 0
                        },
                        'data_points': 0
                    }
                
                if option_type == 'CE':
                    analysis[strike]['ce'].update({
                        'max_oi': record[3],
                        'min_oi': record[4],
                        'avg_oi': record[7]
                    })
                elif option_type == 'PE':
                    analysis[strike]['pe'].update({
                        'max_oi': record[5],
                        'min_oi': record[6],
                        'avg_oi': record[8]
                    })
                
                analysis[strike]['data_points'] = record[9]
            
            return analysis
            
        except Exception as e:
            print(f"❌ Error getting strike analysis: {str(e)}")
            return None
    
    def get_ce_pe_ratio_analysis(self, index_name, start_time=None, end_time=None):
        """Get CE vs PE OI ratio analysis"""
        try:
            connection = self.store.get_connection()
            if connection is None:
                return None
            
            if start_time is None:
                start_time = datetime.now(self.ist_tz) - timedelta(days=1)
            if end_time is None:
                end_time = datetime.now(self.ist_tz)
            
            cursor = connection.cursor()
            cursor.execute('''
                SELECT bucket_ts, trading_symbol, strike,
                       ce_oi, pe_oi,
                       CASE WHEN pe_oi > 0 THEN ce_oi / pe_oi ELSE NULL END as ce_pe_ratio,
                       CASE WHEN ce_oi > 0 THEN pe_oi / ce_oi ELSE NULL END as pe_ce_ratio
                FROM option_snapshots 
                WHERE trading_symbol LIKE %s AND bucket_ts BETWEEN %s AND %s
                ORDER BY bucket_ts, strike
            ''', (f"{index_name}%", start_time, end_time))
            
            records = cursor.fetchall()
            connection.close()
            
            if not records:
                return None
            
            # Process records
            ratio_analysis = {}
            for record in records:
                timestamp, trading_symbol, strike = record[0], record[1], record[2]
                ce_oi, pe_oi = record[3], record[4]
                ce_pe_ratio, pe_ce_ratio = record[5], record[6]
                
                if strike not in ratio_analysis:
                    ratio_analysis[strike] = []
                
                ratio_analysis[strike].append({
                    'timestamp': timestamp,
                    'ce_oi': ce_oi,
                    'pe_oi': pe_oi,
                    'ce_pe_ratio': ce_pe_ratio,
                    'pe_ce_ratio': pe_ce_ratio
                })
            
            return ratio_analysis
            
        except Exception as e:
            print(f"❌ Error getting CE/PE ratio analysis: {str(e)}")
            return None
    
    def get_oi_summary(self, index_name, hours_back=24):
        """Get OI summary for the last N hours"""
        try:
            end_time = datetime.now(self.ist_tz)
            start_time = end_time - timedelta(hours=hours_back)
            
            # Get latest data
            connection = self.store.get_connection()
            if connection is None:
                return None
            
            cursor = connection.cursor()
            cursor.execute('''
                SELECT trading_symbol, option_type, strike,
                       ce_oi, pe_oi, ce_price_close, pe_price_close
                FROM option_snapshots 
                WHERE trading_symbol LIKE %s AND bucket_ts >= %s
                AND bucket_ts = (
                    SELECT MAX(bucket_ts) 
                    FROM option_snapshots s2 
                    WHERE s2.trading_symbol = option_snapshots.trading_symbol
                )
                ORDER BY strike, option_type
            ''', (f"{index_name}%", start_time))
            
            records = cursor.fetchall()
            connection.close()
            
            if not records:
                return None
            
            # Process summary
            summary = {
                'index_name': index_name,
                'analysis_time': end_time,
                'hours_back': hours_back,
                'strikes': {},
                'total_ce_oi': 0,
                'total_pe_oi': 0,
                'pcr': 0  # Put-Call Ratio
            }
            
            for record in records:
                trading_symbol, option_type, strike = record[0], record[1], record[2]
                ce_oi, pe_oi = record[3], record[4]
                ce_price, pe_price = record[5], record[6]
                
                if strike not in summary['strikes']:
                    summary['strikes'][strike] = {
                        'strike': strike,
                        'ce_oi': 0,
                        'pe_oi': 0,
                        'ce_price': 0,
                        'pe_price': 0
                    }
                
                if option_type == 'CE':
                    summary['strikes'][strike]['ce_oi'] = ce_oi
                    summary['strikes'][strike]['ce_price'] = ce_price
                    summary['total_ce_oi'] += ce_oi
                elif option_type == 'PE':
                    summary['strikes'][strike]['pe_oi'] = pe_oi
                    summary['strikes'][strike]['pe_price'] = pe_price
                    summary['total_pe_oi'] += pe_oi
            
            # Calculate PCR
            if summary['total_ce_oi'] > 0:
                summary['pcr'] = summary['total_pe_oi'] / summary['total_ce_oi']
            
            return summary
            
        except Exception as e:
            print(f"❌ Error getting OI summary: {str(e)}")
            return None
    
    def print_oi_summary(self, index_name, hours_back=24):
        """Print formatted OI summary"""
        summary = self.get_oi_summary(index_name, hours_back)
        
        if not summary:
            print(f"❌ No OI summary available for {index_name}")
            return
        
        print(f"\n📊 OI Summary for {index_name}")
        print("=" * 50)
        print(f"⏰ Analysis Time: {summary['analysis_time'].strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"📅 Period: Last {summary['hours_back']} hours")
        print(f"📈 Total CE OI: {summary['total_ce_oi']:,}")
        print(f"📉 Total PE OI: {summary['total_pe_oi']:,}")
        print(f"🔄 Put-Call Ratio: {summary['pcr']:.2f}")
        
        print(f"\n📋 Strike-wise Analysis:")
        print("-" * 50)
        print(f"{'Strike':<8} {'CE OI':<12} {'PE OI':<12} {'CE Price':<10} {'PE Price':<10}")
        print("-" * 50)
        
        for strike in sorted(summary['strikes'].keys()):
            strike_data = summary['strikes'][strike]
            print(f"{strike:<8} {strike_data['ce_oi']:<12,} {strike_data['pe_oi']:<12,} "
                  f"{strike_data['ce_price']:<10.2f} {strike_data['pe_price']:<10.2f}")

def main():
    """Main function for testing OI analysis"""
    analyzer = OIAnalysis()
    
    # Test OI summary
    print("🧪 Testing OI Analysis...")
    analyzer.print_oi_summary('NIFTY', 24)

if __name__ == "__main__":
    main() 